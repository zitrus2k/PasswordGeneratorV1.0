# print('Password Generator 1.0')
#
# import random
#
# letters = [ A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z]
# numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
#
# print('Generated Password :' , letters.randint())



print('  Password Generator v1.0   ')
print()
print('     Made By zitrus2k')

print()

import random
import string

print('Do you want any special words in the Password?')
password_w = input('Enter : ')

def generate_password(length):
    password = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    return password

print('How long should your Password be?')
len_input = int(input('Enter : '))

if len_input == 0:
    print('ERROR 01x '
          'your Password is 0!')


password = generate_password(len_input)
print("Your generated password is:", password + '_' + password_w)

print()
print('-Zitrus Studios Development-')